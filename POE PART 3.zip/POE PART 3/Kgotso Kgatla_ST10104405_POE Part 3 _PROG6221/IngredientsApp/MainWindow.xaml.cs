﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IngredientsApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeWindow recipeWindow = new RecipeWindow();
            bool? result = recipeWindow.ShowDialog();

            if (result == true)
            {
                recipes.Add(recipeWindow.Recipe);
                RefreshRecipeListBox();
            }
        }

        private void DisplayAllButton_Click(object sender, RoutedEventArgs e)
        {
            if (recipes.Count == 0)
            {
                MessageBox.Show("No recipes found.");
                return;
            }

            DisplayRecipesWindow displayRecipesWindow = new DisplayRecipesWindow(recipes);
            displayRecipesWindow.ShowDialog();
        }

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            if (recipes.Count == 0)
            {
                MessageBox.Show("No recipes found.");
                return;
            }

            SelectRecipeWindow selectRecipeWindow = new SelectRecipeWindow(recipes);
            bool? result = selectRecipeWindow.ShowDialog();

            if (result == true)
            {
                Recipe selectedRecipe = selectRecipeWindow.SelectedRecipe;
                DisplayRecipeWindow displayRecipeWindow = new DisplayRecipeWindow(selectedRecipe);
                displayRecipeWindow.ShowDialog();
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void RefreshRecipeListBox()
        {
            recipeListBox.ItemsSource = null;
            recipeListBox.ItemsSource = recipes.OrderBy(r => r.Name);
        }
    }
}