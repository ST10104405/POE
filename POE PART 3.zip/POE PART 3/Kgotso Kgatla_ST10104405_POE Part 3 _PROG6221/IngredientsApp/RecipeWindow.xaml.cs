﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IngredientsApp
{
    /// <summary>
    /// Interaction logic for RecipeWindow.xaml
    /// </summary>
   
        public partial class RecipeWindow : Window
        {
            private Recipe recipe;

            public RecipeWindow()
            {
                InitializeComponent();

                // Initialize a new Recipe object
                recipe = new Recipe();
            }

            private void AddIngredientsButton_Click(object sender, RoutedEventArgs e)
            {
                int numIngredients = Convert.ToInt32(numIngredientsTextBox.Text);

                // Clear existing ingredients
                recipe.Ingredients.Clear();

                for (int i = 0; i < numIngredients; i++)
                {
                    Ingredient ingredient = new Ingredient();
                    recipe.Ingredients.Add(ingredient);
                }

                // Refresh the ingredients ItemsControl
                ingredientsItemsControl.ItemsSource = null;
                ingredientsItemsControl.ItemsSource = recipe.Ingredients;
            }

            private void AddStepsButton_Click(object sender, RoutedEventArgs e)
            {
                int numSteps = Convert.ToInt32(numStepsTextBox.Text);

                // Clear existing steps
                recipe.Steps.Clear();

                for (int i = 0; i < numSteps; i++)
                {
                    Step step = new Step();
                    step.StepNumber = i + 1;
                    recipe.Steps.Add(step);
                }

                // Refresh the steps ItemsControl
                stepsItemsControl.ItemsSource = null;
                stepsItemsControl.ItemsSource = recipe.Steps;
            }

            private void SaveButton_Click(object sender, RoutedEventArgs e)
            {
                // Save the recipe or perform any other necessary actions
                // Here, we are simply displaying the recipe details in a message box
                string recipeDetails = $"Recipe Name: {recipeNameTextBox.Text}\n\nIngredients:\n";
                foreach (var ingredient in recipe.Ingredients)
                {
                    recipeDetails += $"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}\n";
                }
                recipeDetails += "\nSteps:\n";
                foreach (var step in recipe.Steps)
                {
                    recipeDetails += $"{step.StepNumber}. {step.Description}\n";
                }

                MessageBox.Show(recipeDetails, "Recipe Details");
            }
        }
    }

